w3.includeHTML()
w3.swap(".main")
/*
    w3.swap is my custom addon to the JavaScript part of the framework
    w3.swap will hide all the elements with the w3-switch class, and show only the selected one
*/

// Start your code here
